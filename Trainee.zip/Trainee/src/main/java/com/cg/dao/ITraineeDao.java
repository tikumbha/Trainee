package com.cg.dao;





import java.util.ArrayList;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Trainee;

public interface ITraineeDao {
 
	@Transactional
	public void save(Trainee t);
	@Transactional
	public Trainee read(int id);
	//@Transactional
	public Trainee update(int id);
	@Transactional
	public Trainee delete(int traineeId);
	@Transactional
	public List<Trainee> find();
}
