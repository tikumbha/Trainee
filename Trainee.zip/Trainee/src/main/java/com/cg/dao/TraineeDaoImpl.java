package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Trainee;


public class TraineeDaoImpl implements ITraineeDao {

	@PersistenceContext
	EntityManager em;
	
	
	@Override
	public void save(Trainee t) {
		// TODO Auto-generated method stub
		
		em.persist(t);
		
	}

	@Override
	public Trainee read(int traineeId) {
		// TODO Auto-generated method stub
		Trainee t=em.find(Trainee.class,traineeId);
		return t;
	}

	@Override
	public Trainee update(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Trainee delete(int traineeId) {
		// TODO Auto-generated method stub
		System.out.println("In deleteDAo");
		Trainee t=em.find(Trainee.class,traineeId);
		System.out.println(t);
		em.remove(t);
		return t;
	}

	@Override
	public List<Trainee> find() {
		List<Trainee> listTrainee = em.createQuery("SELECT t FROM Trainee t").getResultList();
		if(listTrainee==null) {
		System.out.println("No trainee found..");	
		}
		
		return listTrainee;
		
//		ArrayList<Trainee> lls = new ArrayList<Trainee>();
//		em.find(Trainee.class, em).getTraineeId();
//		return lls;
	}

}
