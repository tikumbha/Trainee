package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.validation.BindingResult;

import com.cg.bean.Trainee;


public interface ITraineeService {

	public String newRecord(Trainee t,BindingResult result);
	public Trainee readTable(int traineeId);
	public Trainee updateTable(int id); 
	public Trainee deleteTable(int traineeId);
	public List<Trainee> fetchAll();
}
