package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.validation.BindingResult;

import com.cg.bean.Trainee;
import com.cg.dao.ITraineeDao;


public class TraineeServiceImpl implements ITraineeService {

	ITraineeDao traineeDao;

	public TraineeServiceImpl(ITraineeDao traineeDao) {
		super();
		this.traineeDao = traineeDao;
	}

	@Override
	public String newRecord(Trainee t, BindingResult result) {
		// TODO Auto-generated method stub

		if(result.hasErrors()) {
			return "ERROR";
		}
		traineeDao.save(t);
		return "SUCCESS";
		
	}

	@Override
	public Trainee readTable(int traineeId) {
		// TODO Auto-generated method stub
		Trainee t= traineeDao.read(traineeId);
		return t;
	}

	@Override
	public Trainee updateTable(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Trainee deleteTable(int traineeId) {
		// TODO Auto-generated method stub
		Trainee t= traineeDao.delete(traineeId);
		return t;
	}

	@Override
	public List<Trainee> fetchAll() {
		// TODO Auto-generated method stub
		List<Trainee> ls = traineeDao.find();
		return ls;
	}

}
