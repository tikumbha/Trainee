package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.AdminCredentials;
import com.cg.bean.Trainee;
import com.cg.service.TraineeServiceImpl;


@Controller
public class TraineeController {
	
	@Autowired
	TraineeServiceImpl impl;
	
	@RequestMapping(method=RequestMethod.GET,path="/")
	public String say() {
		return "start";
	}
	//LOGIN PAGE
	@RequestMapping(method=RequestMethod.GET,path="/pages")
	public String sayHello(@ModelAttribute("c")AdminCredentials c) {
		return "login";
	}
	
	//LOGIN LOGIC
	//@Transactional
	@RequestMapping (path="/index",method= RequestMethod.POST)
	private ModelAndView login(@ModelAttribute("c")AdminCredentials c) {
		
		ModelAndView mv= new ModelAndView();
		
		mv.setViewName("login");
		
		if(c.getUserName().equals("abc"))
		{
		 if(c.getPassword().equals("abc"))
		 {
			 mv.setViewName("index");
			 return mv;
			 
		}
		}
		 return mv;
	}
	
	//CREATE PAGE
	//@Transactional
	@RequestMapping(method=RequestMethod.GET,path="/create")
	public String createData(@ModelAttribute("t") Trainee t) {
		return "create";
	}
//	
	
//		@RequestMapping(path="/create",method=RequestMethod.GET)
//		public ModelAndView newEmployee(@ModelAttribute("t")  Trainee t,BindingResult result) 
//		{
//			ModelAndView mv= new ModelAndView();
//			mv.setViewName("index");
//			String name = impl.newRecord(t, result);
//		if(result.hasErrors())
//		return mv;
//		mv.setViewName("create");
//		mv.addObject("key",t.getTraineeId());
//		return mv;
//		}
		
	
		//@Transactional
		@RequestMapping(path="/added",method=RequestMethod.POST)
		public ModelAndView addTrainee(@ModelAttribute("t") @Valid Trainee t,BindingResult result) 
		{
			
			ModelAndView mv= new ModelAndView();
			mv.setViewName("create");
			String name = impl.newRecord(t, result);
		if(result.hasErrors())
		return mv;
		mv.setViewName("added");
		mv.addObject("key",t.getTraineeId());
	//	mv.addObject("key",t.getTraineeName());
		return mv;
		}
		
		//DELETE
		@RequestMapping(method=RequestMethod.GET, path="/getdelete")
		public String deleteData(@ModelAttribute("t") Trainee t) {
			return "delete";
		}
		
		@RequestMapping(path="/delete",method=RequestMethod.POST)
		public ModelAndView deleteTrainee(@ModelAttribute("t") Trainee t) 
		{
			ModelAndView mv= new ModelAndView();
			mv.setViewName("delete");
			Trainee t1= impl.deleteTable(t.getTraineeId());
			System.out.println(t1.getTraineeId());
			mv.addObject("key",t1.getTraineeName());
			mv.addObject("key1",t1.getTraineeId());
			mv.addObject("key2",t1.getTraineeLocation());
			mv.addObject("key3",t1.getTraineeDomain());
			
		return mv;
		}
		
		//UPDATE
			@RequestMapping(method=RequestMethod.GET, path="/getupdate")
			public String updateData(@ModelAttribute("t") Trainee t) {
			return "update";
		}
			
			@RequestMapping(path="/update",method=RequestMethod.POST)
			public ModelAndView updateTrainee(@ModelAttribute("t") Trainee t) 
			{
		//	System.out.println("in deleteEmpController"+t.getI());
				
				ModelAndView mv= new ModelAndView();
				//em.remove(e);
				
				mv.setViewName("delete");
				Trainee t1= impl.deleteTable(t.getTraineeId());
				System.out.println(t1.getTraineeId());
				mv.addObject("key",t1.getTraineeName());
				mv.addObject("key1",t1.getTraineeId());
				mv.addObject("key2",t1.getTraineeLocation());
				mv.addObject("key3",t1.getTraineeDomain());
				
			return mv;
			}
		
			
			
			//RETRIEVE
			
			@RequestMapping(method=RequestMethod.GET, path="/gretrieve")
			public String retrieveData(@ModelAttribute("t") Trainee t) {
				return "retrieve";
			}
			
			@RequestMapping(path="/retrieve",method=RequestMethod.POST)
			public ModelAndView retrieveTrainee(@ModelAttribute("t") Trainee t) 
			{
				ModelAndView mv= new ModelAndView();
				mv.setViewName("retrieve");
				Trainee t1= impl.readTable(t.getTraineeId());
				System.out.println(t1.getTraineeId());
				mv.addObject("key",t1.getTraineeName());
				mv.addObject("key1",t1.getTraineeId());
				mv.addObject("key2",t1.getTraineeLocation());
				mv.addObject("key3",t1.getTraineeDomain());
				
			return mv;
			}
			
			
			//RETRIEVEALL
			@RequestMapping(method=RequestMethod.GET, path="/readAll")
			public ModelAndView retrieveAll(@ModelAttribute("t") Trainee t,Model model) {
				
				ModelAndView mv = new ModelAndView();
				List<Trainee> list=impl.fetchAll();
				model.addAttribute("Trainee",t);
				mv.addObject("tlist",list);
				mv.addObject("t",new Trainee());
				mv.setViewName("traineeinfo");
				return mv;
//				List<Trainee> list = new ArrayList<Trainee>();
//				list = impl.fetchAll();
//				mv.addObject("tlist", list);
//				return "retrieveAll";
			}

	}
	
	
	

