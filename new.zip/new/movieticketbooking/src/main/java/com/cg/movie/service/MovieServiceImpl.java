package com.cg.movie.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.BindingResult;


import com.cg.movie.bean.MovieBean;
import com.cg.movie.dao.IMovieDao;
import com.cg.movie.exception.MovieNotFoundException;

public class MovieServiceImpl implements IMovieService{

	IMovieDao dao;
	
	public MovieServiceImpl(IMovieDao dao)
	{
		super();
		this.dao = dao;
	}


	@Override
	public String addMovie(@Valid MovieBean m, BindingResult result) {
		if(result.hasErrors())
        {
            return "Error";
        }
        dao.save(m);
        return "Success";
	}


	@Override
	public MovieBean deleteMovie(int id) {
		// TODO Auto-generated method stub
		return dao.delete(id);
	}


	@Override
	public List<MovieBean> getAllMovies() {
		// TODO Auto-generated method stub
		return dao.getAll();
	}


	@Override
	public MovieBean getMovie(int id) throws MovieNotFoundException {
		MovieBean tr = dao.get(id);
		if (tr == null)
		{
			throw new MovieNotFoundException("No movie found with this ID");
		}
		else 
		{
			return dao.get(id);
		}

	}
}
	
	

