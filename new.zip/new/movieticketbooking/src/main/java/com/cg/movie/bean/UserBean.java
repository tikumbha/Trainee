package com.cg.movie.bean;

import java.util.ArrayList;
import java.util.List;

public class UserBean 
{
private String name;
private long phn;

private List<String> seatno = new ArrayList<String>();


public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public long getPhn() {
	return phn;
}
public void setPhn(long phn) {
	this.phn = phn;
}
public List<String> getSeatno() {
	return seatno;
}
public void setSeatno(List<String> seatno) {
	this.seatno = seatno;
}
@Override
public String toString() {
	return "UserBean [name=" + name + ", phn=" + phn + ", seatno=" + seatno + "]";
}




}
