package com.cg.movie.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import javax.validation.Valid;


import com.cg.movie.bean.MovieBean;

@Transactional
public class MovieDaoImpl implements IMovieDao {

	

    @PersistenceContext
    EntityManager em;
	@Override
	public void save(@Valid MovieBean m) {
		// TODO Auto-generated method stub
		em.persist(m);
	}
	@Override
	public MovieBean delete(int id) {
		MovieBean m = em.find(MovieBean.class, id);
		em.remove(m);
		return m;
	}
	@Override
	public MovieBean get(int id) {
		MovieBean m = em.find(MovieBean.class, id);
		return m;
	}
	@Override
	public List<MovieBean> getAll() {
		List<MovieBean> listMovie = em.createQuery("SELECT m FROM MovieBean m").getResultList();

		if (listMovie == null) {
			System.out.println("No Movie found ... ");
		} else {
			for (MovieBean movie : listMovie) {
				System.out.println(movie);
			}
		}

		return listMovie;
	}

	}
	
	

