package com.cg.movie.dao;

import java.util.List;

import javax.validation.Valid;


import com.cg.movie.bean.MovieBean;

public interface IMovieDao {

	public void save(@Valid MovieBean m);
	
	public MovieBean delete(int id);
	
	public MovieBean get(int id);
	
	public List<MovieBean> getAll();

}
