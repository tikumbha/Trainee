package com.cg.movie.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.cg.movie.bean.AdminBean;
import com.cg.movie.bean.MovieBean;
import com.cg.movie.bean.UserBean;
import com.cg.movie.exception.MovieNotFoundException;
import com.cg.movie.service.MovieServiceImpl;

@Controller
public class MovieController {

	@Autowired
	MovieServiceImpl service;
	
	// Index Page
		@RequestMapping(value = "/", method = RequestMethod.GET)
		public String index() {
			return "index";
		}
		
		
		// Login method
		@RequestMapping(path = "/login", method = RequestMethod.GET)
		public String getStared(@ModelAttribute("admin") AdminBean admin) {
			return "login";
		}
		

		// Movie Page
		@RequestMapping(path = "/movies", method = RequestMethod.GET)
		public ModelAndView movies() {
			System.out.println("In movie info page ...");
			ModelAndView mv = new ModelAndView();

			List<MovieBean> list = new ArrayList<MovieBean>();
			list = service.getAllMovies();
			mv.addObject("tlist", list);
			mv.addObject("movie", new MovieBean());
			mv.setViewName("movie");
			return mv;
			
			
			
			
		}
		
		// Home page method
				@RequestMapping(path = "/homepage", method = RequestMethod.GET)
				public String goToHomePage() {
					return "updatemovie";
				}
				
				@RequestMapping(path = "/operations", method = RequestMethod.POST)
				public ModelAndView auth(@ModelAttribute("admin") AdminBean admin) {

					ModelAndView mv = new ModelAndView();
					if (admin.getUsername().equals("admin") && admin.getPassword().equals("12345")) {
						mv.setViewName("updatemovie");
						System.out.println("Authenticated ...");
					} else {
						mv.setViewName("login");
						System.out.println("Wrong username and password");
					}

					return mv;
				}		
				
				// Add Movie method
				@RequestMapping(path = "/addmovies", method = RequestMethod.GET)
				public ModelAndView newMovie(@ModelAttribute("m") MovieBean mb) {

					ModelAndView mv = new ModelAndView();
					System.out.println("In add movie page ...");
					ArrayList<String> al = new ArrayList<String>();
					al.add("1");
					al.add("2");
					al.add("3");
					al.add("4");
					al.add("5");
					
					System.out.println("List:  " + al);
					mv.addObject("clist", al);
					mv.setViewName("add");
					return mv;

				}
				
				@RequestMapping(path = "getMovieData", method = RequestMethod.POST)
				public ModelAndView addMovies(@ModelAttribute("m") @Valid MovieBean mb, BindingResult result) {

					ModelAndView mv = new ModelAndView();
					String res = service.addMovie(mb, result);
					if (result.hasErrors()) {
						
						ArrayList<String> al = new ArrayList<String>();
						al.add("1");
						al.add("2");
						al.add("3");
						al.add("4");
						al.add("5");
						
						System.out.println("List:  " + al);
						mv.addObject("clist", al);
						mv.setViewName("add");
						return mv;
					}
					System.out.println(mb);
					mv.setViewName("movie");
					List<MovieBean> list = new ArrayList<MovieBean>();
					list.add(mb);
					mv.addObject("tlist", list);
					mv.addObject("movie", new MovieBean());
					return mv;

				}
				
				// Delete Movie method
				@RequestMapping(path = "/delete", method = RequestMethod.GET)
				public String delete(@ModelAttribute("movie") MovieBean mb) {

					System.out.println("In delete trainee page ...");
					return "delete";

				}
				
				@RequestMapping(path = "deleteMovies", method = RequestMethod.POST)
				public ModelAndView deleteMovies(@ModelAttribute("movie") MovieBean mb, BindingResult result)
						throws MovieNotFoundException {
					ModelAndView mv = new ModelAndView();

					List<MovieBean> list = new ArrayList<MovieBean>();
					try {
						MovieBean movie = service.deleteMovie(mb.getMovieId());
						list.add(movie);
						mv.addObject("tlist", list);
						mv.addObject("movie", new MovieBean());
						mv.setViewName("movie");
					} catch (Exception e) {

						throw new MovieNotFoundException("No movie found with this ID");
					}

					return mv;
				}
				
				// Retrieve one movie
				@RequestMapping(path = "/getMovie", method = RequestMethod.GET)
				public String get(@ModelAttribute("movie") MovieBean mb) {

					System.out.println("In delete ovie page ...");
					return "getMovie";

				}

				@RequestMapping(path = "getMovieDetails", method = RequestMethod.POST)
				public ModelAndView getMovie(@ModelAttribute("movie") MovieBean mb) throws MovieNotFoundException {
					ModelAndView mv = new ModelAndView();

					try {
						MovieBean movie = service.getMovie(mb.getMovieId());
						System.out.println(movie);
						List<MovieBean> list = new ArrayList<MovieBean>();
						list.add(movie);
						mv.addObject("tlist", list);
						mv.addObject("movie", new MovieBean());
						mv.setViewName("movie");
					} catch (Exception e) {
						throw new MovieNotFoundException("No movie found with this ID");
					}
					return mv;
				}

				// Retrieve all Movies

				@RequestMapping(path = "/getAllMovies", method = RequestMethod.GET)
				public ModelAndView getAll() {

					System.out.println("In movie info page ...");
					ModelAndView mv = new ModelAndView();

					List<MovieBean> list = new ArrayList<MovieBean>();
					list = service.getAllMovies();
					mv.addObject("tlist", list);
					mv.addObject("movie", new MovieBean());
					mv.setViewName("movie");
					return mv;

				}
				
				
				
	/*
	 * @RequestMapping(path = "/showtimings", method = RequestMethod.GET) public
	 * String showtiming(@ModelAttribute("user") UserBean user) {
	 * 
	 * System.out.println("In showtimings page..."); return "showtimings";
	 * 
	 * }
	 */
				
				@RequestMapping(path = "/seatbooking", method = RequestMethod.GET)
				public String seatbooking(@ModelAttribute("user") UserBean user) {

					System.out.println("In seat booking  page ...");
					return "seatbooking";

				}
				
				
				
				
				@RequestMapping(path = "/bookticket", method = RequestMethod.POST)
				public ModelAndView auth(@ModelAttribute("user") UserBean user, BindingResult result) {

					ModelAndView mv = new ModelAndView();
				
					System.out.println("User"+user);
					
					List<UserBean> seat = new ArrayList<UserBean>();
					mv.addObject("seat", user.getSeatno());
					//mv.addObject("seat", user.getName());
					mv.setViewName("bookticket");
					return mv;
				}	
				
	/*
	 * @RequestMapping(path = "/ticket", method = RequestMethod.GET) public String
	 * ticketprice(@ModelAttribute("user") UserBean user) {
	 * 
	 * System.out.println("In payment page ..."); return "ticket";
	 * 
	 * }
	 */
				
				@RequestMapping(path = "/ticket", method = RequestMethod.POST)
				public ModelAndView ticketprice(@ModelAttribute("user") UserBean user, BindingResult result) {

					ModelAndView mv = new ModelAndView();
					System.out.println("User123333333333333333"+user);
					List<UserBean> seat = new ArrayList<UserBean>();
					mv.addObject("seat", user.getName());
					//mv.addObject("seat", user.getSeatno());
					System.out.println(user.getSeatno());
					mv.setViewName("ticket");
					return mv;
				}	
				
}
