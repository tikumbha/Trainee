package com.cg.movie.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
public class MovieBean 

{

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int movieId;

	//@Size(max=20, min=2, message = "Name must be in range of 2-20")
	@NotNull(message = "Name is compulsory")
  //  @NotBlank(message = "Name is compulsory")
    @Pattern(regexp = "[a-z-A-Z ]*", message = "First name has invalid characters")
	private String movieName;

	private String movieLang;

	private String movieLocation;
	
	float rating;
	
	private String releasedate;
	
	private String duration;
	
	// TO STRING
	@Override
	public String toString() {
		return "MovieBean [movieId=" + movieId + ", movieName=" + movieName + ", movieLang=" + movieLang
				+ ", movieLocation=" + movieLocation + ", rating=" + rating + ", releasedate=" + releasedate
				+ ", duration=" + duration + "]";
	}

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getMovieLang() {
		return movieLang;
	}

	public void setMovieLang(String movieLang) {
		this.movieLang = movieLang;
	}

	public String getMovieLocation() {
		return movieLocation;
	}

	public void setMovieLocation(String movieLocation) {
		this.movieLocation = movieLocation;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public String getReleasedate() {
		return releasedate;
	}

	public void setReleasedate(String releasedate) {
		this.releasedate = releasedate;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}
	
	
	
	
	
	
	
}
