package com.cg.movie.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.BindingResult;


import com.cg.movie.bean.MovieBean;
import com.cg.movie.exception.MovieNotFoundException;



public interface IMovieService {
	
	public String addMovie(@Valid MovieBean m, BindingResult result);
	
	public MovieBean deleteMovie(int id);
	
	public List<MovieBean> getAllMovies();
	
	public MovieBean getMovie(int id) throws MovieNotFoundException;


}
