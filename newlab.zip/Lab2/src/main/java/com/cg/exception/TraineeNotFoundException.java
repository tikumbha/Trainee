package com.cg.exception;


public class TraineeNotFoundException extends Exception {

	public TraineeNotFoundException() {
		super();
	}

	public TraineeNotFoundException(String message) {
		super(message);
		
	}
}
	 
