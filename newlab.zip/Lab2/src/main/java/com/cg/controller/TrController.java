package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Admin;
import com.cg.bean.Trainees;
import com.cg.exception.TraineeNotFoundException;
import com.cg.service.TrService;

@Controller
public class TrController {

	@Autowired
	TrService service;

	// Index Page
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String index() {
		return "index";
	}

	// Error Page
	@RequestMapping(value = "/error", method = RequestMethod.GET)
	public String error() {
		return "error";
	}

	// Login method
	@RequestMapping(path = "/login", method = RequestMethod.GET)
	public String getStared(@ModelAttribute("admin") Admin admin) {
		return "login";
	}
	
	// Home page method
		@RequestMapping(path = "/homepage", method = RequestMethod.GET)
		public String goToHomePage() {
			return "menu";
		}

	@RequestMapping(path = "/operations", method = RequestMethod.POST)
	public ModelAndView auth(@ModelAttribute("admin") Admin admin) {

		ModelAndView mv = new ModelAndView();
		if (admin.getUsername().equals("admin") && admin.getPassword().equals("12345")) {
			mv.setViewName("menu");
			System.out.println("Authenticated ...");
		} else {
			mv.setViewName("login");
			System.out.println("Wrong username and password");
		}

		return mv;

	}

	// Add trainee method
	@RequestMapping(path = "/addTrainee", method = RequestMethod.GET)
	public ModelAndView newTrainee(@ModelAttribute("t") Trainees tr) {

		ModelAndView mv = new ModelAndView();
		System.out.println("In add trainee page ...");
		ArrayList<String> al = new ArrayList<String>();
		al.add("Jee with Cloud");
		al.add("Javascript");
		al.add("SAP");
		al.add("BI");
		al.add("JEE");

		System.out.println("List:  " + al);
		mv.addObject("clist", al);
		mv.setViewName("add");
		return mv;

	}

	@RequestMapping(path = "getTraineeData", method = RequestMethod.POST)
	public ModelAndView addTrainee(@ModelAttribute("t") @Valid Trainees tr, BindingResult result) {

		ModelAndView mv = new ModelAndView();
		String res = service.addTrainee(tr, result);
		if (result.hasErrors()) {
			ArrayList<String> al = new ArrayList<String>();
			al.add("Jee with Cloud");
			al.add("Javascript");
			al.add("SAP");
			al.add("BI");
			al.add("JEE");

			System.out.println("List:  " + al);
			mv.addObject("clist", al);
			mv.setViewName("add");
			return mv;
		}
		System.out.println(tr);
		mv.setViewName("trainee");
		List<Trainees> list = new ArrayList<Trainees>();
		list.add(tr);
		mv.addObject("tlist", list);
		mv.addObject("trainee", new Trainees());
		return mv;

	}

	// Delete Trainee method
	@RequestMapping(path = "/delete", method = RequestMethod.GET)
	public String delete(@ModelAttribute("trainee") Trainees tr) {

		System.out.println("In delete trainee page ...");
		return "delete";

	}

	@RequestMapping(path = "deleteTrainee", method = RequestMethod.POST)
	public ModelAndView deleteTrainee(@ModelAttribute("trainee") Trainees tr, BindingResult result)
			throws TraineeNotFoundException {
		ModelAndView mv = new ModelAndView();

		List<Trainees> list = new ArrayList<Trainees>();
		try {
			Trainees trainee = service.deleteTrainee(tr.getTraineeId());
			list.add(trainee);
			mv.addObject("tlist", list);
			mv.addObject("trainee", new Trainees());
			mv.setViewName("trainee");
		} catch (Exception e) {

			throw new TraineeNotFoundException("No trainee found with this ID");
		}

		return mv;
	}

	// Modify trainee
	@RequestMapping(path = "/modify", method = RequestMethod.GET)
	public String modify(@ModelAttribute("trainee") Trainees tr) {

		System.out.println("In modify trainee page ...");
		return "getidformodify";

	}

	@RequestMapping(path = "modifyDetails", method = RequestMethod.POST)
	public ModelAndView modifyTrainee(@ModelAttribute("t") Trainees tr) throws TraineeNotFoundException {
		ModelAndView mv = new ModelAndView();

		try {
			Trainees trainee = service.getTrainee(tr.getTraineeId());
			System.out.println(trainee);
			mv.addObject("tr", trainee);
			ArrayList<String> al = new ArrayList<String>();
			al.add("Jee with Cloud");
			al.add("Javascript");
			al.add("SAP");
			al.add("BI");
			al.add("JEE");

			System.out.println("List:  " + al);
			mv.addObject("list", al);
			mv.setViewName("modify");
		} catch (Exception e) {

			throw new TraineeNotFoundException("No trainee found with this ID");
		}

		return mv;
	}

	@RequestMapping(path = "modifyRecord", method = RequestMethod.POST)
	public ModelAndView modifyRecord(@ModelAttribute("t") @Valid Trainees tr) {
		ModelAndView mv = new ModelAndView();
		Trainees trainee = service.modifyTrainee(tr);
		System.out.println(trainee);
		mv.setViewName("menu");
		return mv;
	}

	// Retrieve one trainee
	@RequestMapping(path = "/getTrainee", method = RequestMethod.GET)
	public String get(@ModelAttribute("trainee") Trainees tr) {

		System.out.println("In delete trainee page ...");
		return "getTrainee";

	}

	@RequestMapping(path = "getTraineeDetails", method = RequestMethod.POST)
	public ModelAndView getTrainee(@ModelAttribute("trainee") Trainees tr) throws TraineeNotFoundException {
		ModelAndView mv = new ModelAndView();

		try {
			Trainees trainee = service.getTrainee(tr.getTraineeId());
			System.out.println(trainee);
			List<Trainees> list = new ArrayList<Trainees>();
			list.add(trainee);
			mv.addObject("tlist", list);
			mv.addObject("trainee", new Trainees());
			mv.setViewName("trainee");
		} catch (Exception e) {
			throw new TraineeNotFoundException("No trainee found with this ID");
		}
		return mv;
	}

	// Retrieve all trainees

	@RequestMapping(path = "/getAll", method = RequestMethod.GET)
	public ModelAndView getAll() {

		System.out.println("In trainee info page ...");
		ModelAndView mv = new ModelAndView();

		List<Trainees> list = new ArrayList<Trainees>();
		list = service.getAllTrainee();
		mv.addObject("tlist", list);
		mv.addObject("trainee", new Trainees());
		mv.setViewName("trainee");
		return mv;

	}

	// get trainee details by clicking link
	@RequestMapping(path = "traineeDetails/{id}", method = RequestMethod.GET)
	public ModelAndView readEmployee(@PathVariable("id") int id) throws TraineeNotFoundException {
		Trainees trainee;
		ModelAndView mv = new ModelAndView();

		try {
			trainee = service.getTrainee(id);
			System.out.println(trainee);
			List<Trainees> list = new ArrayList<Trainees>();
			list.add(trainee);
			mv.addObject("tlist", list);
			mv.addObject("trainee", new Trainees());
			mv.setViewName("trainee");
		} catch (TraineeNotFoundException e) {
			// TODO Auto-generated catch block
			throw new TraineeNotFoundException("No trainee found with this ID");
		}
	
		
		return mv;

	}

}
