package com.cg.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
public class Trainees {

	

	// @Min(value = 2, message = "Must be a Length of atleast two")
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int traineeId;

	//@Size(max=20, min=2, message = "Name must be in range of 2-20")
	@NotNull(message = "Name is compulsory")
  //  @NotBlank(message = "Name is compulsory")
    @Pattern(regexp = "[a-z-A-Z ]*", message = "First name has invalid characters")
	private String traineeName;

	private String traineeDomain;

	private String traineeLocation;

	// TO STRING
	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName=" + traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLocation=" + traineeLocation + "]";
	}

	// GETTERS AND SETTERS
	public int getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public String getTraineeDomain() {
		return traineeDomain;
	}

	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}

	public String getTraineeLocation() {
		return traineeLocation;
	}

	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
}
