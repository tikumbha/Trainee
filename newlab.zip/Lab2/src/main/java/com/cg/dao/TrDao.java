package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import com.cg.bean.Trainees;

@Transactional
public class TrDao implements ITrDao{


    @PersistenceContext
    EntityManager em;
    
    
	@Override
	public void save(Trainees t) {
		// TODO Auto-generated method stub
		em.persist(t);
	}

	@Override
	public Trainees delete(int id) {
		Trainees t = em.find(Trainees.class, id);
		em.remove(t);
		return t;
	}

	@Override
	public List<Trainees> getAll() {
		List<Trainees> listTrainee = em.createQuery("SELECT t FROM Trainees t").getResultList();

		if (listTrainee == null) {
			System.out.println("No Trainee found ... ");
		} else {
			for (Trainees trainee : listTrainee) {
				System.out.println(trainee);
			}
		}

		return listTrainee;

	}

	@Override
	public Trainees get(int id) {
		Trainees t = em.find(Trainees.class, id);
		return t;
	}

	@Override
	public Trainees modify(Trainees t) {
		Trainees tr = em.merge(t);
		return tr;
	}

}
