package com.cg.dao;

import java.util.List;

import com.cg.bean.Trainees;


public interface ITrDao {

	public void save(Trainees t);

	public Trainees delete(int id);

	public List<Trainees> getAll();
	
	public Trainees get(int id);
	
	public Trainees modify(Trainees t);

}
