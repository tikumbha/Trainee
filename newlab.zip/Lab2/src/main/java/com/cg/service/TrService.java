package com.cg.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.BindingResult;

import com.cg.bean.Trainees;
import com.cg.dao.ITrDao;
import com.cg.exception.TraineeNotFoundException;

public class TrService implements ITrService{

	ITrDao dao;
	
	
	public TrService(ITrDao dao) {
		super();
		this.dao = dao;
	}

	public ITrDao getDao() {
		return dao;
	}

	public void setDao(ITrDao dao) {
		this.dao = dao;
	}

	@Override
	public String addTrainee(@Valid Trainees t, BindingResult result) {
		  
        if(result.hasErrors())
        {
            return "Error";
        }
        dao.save(t);
        return "Success";
	}

	@Override
	public Trainees deleteTrainee(int id) {
		// TODO Auto-generated method stub
		return dao.delete(id);
	}

	@Override
	public List<Trainees> getAllTrainee() {
		return dao.getAll();
	}

	@Override
	public Trainees getTrainee(int id) throws TraineeNotFoundException {
		Trainees tr = dao.get(id);
		if (tr == null)
		{
			throw new TraineeNotFoundException("No trainee found with this ID");
		}
		else 
		{
			return dao.get(id);
		}
	}

	@Override
	public Trainees modifyTrainee(Trainees t) {
		return dao.modify(t);	}

}
