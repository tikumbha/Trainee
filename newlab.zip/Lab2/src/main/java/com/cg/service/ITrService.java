package com.cg.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.BindingResult;

import com.cg.bean.Trainees;
import com.cg.exception.TraineeNotFoundException;


public interface ITrService {

	public String addTrainee(@Valid Trainees t, BindingResult result);

	public Trainees deleteTrainee(int id);

	public List<Trainees> getAllTrainee();
	
	public Trainees getTrainee(int id) throws TraineeNotFoundException;
	
	public Trainees modifyTrainee(Trainees t);
}
