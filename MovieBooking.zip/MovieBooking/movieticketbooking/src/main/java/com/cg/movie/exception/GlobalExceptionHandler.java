package com.cg.movie.exception;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class GlobalExceptionHandler {



//	@ResponseBody
//	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason = "Trainee not found with this ID")
	@ExceptionHandler(value = {Exception.class})
    protected void handleConflict(Exception ex, HttpServletRequest req, HttpServletResponse res) {
        String bodyOfResponse = ex.getMessage();// "Country with this id not present";
        String uri = req.getRequestURL().toString();
        System.out.println("Response body ... "+bodyOfResponse);
        System.out.println("URI is: "+uri);
        try {
        	req.setAttribute("msg", bodyOfResponse);
			res.sendRedirect("http://localhost:8081/movieticketbooking/error");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     
    }


}
